# LegalEase — AI-Powered Legal Document Generator

LegalEase is a Streamlit + FastAPI application that generates editable legal-document drafts with Google Gemini and exports them as TXT, DOCX, and PDF.

The implementation follows the supplied project document: document type, parties, terms, effective date, editable preview, branded exports, FastAPI `/generate`, Streamlit frontend, and environment-based Gemini configuration.

> **Important:** LegalEase produces AI-generated legal-information drafts, not legal advice. Users should have important documents reviewed by a qualified lawyer before relying on them.

## Architecture

```text
Streamlit UI
    |
    | POST /generate
    v
FastAPI backend
    |
    v
GeminiDocumentGenerator
    |
    v
Google Gemini API

Generated text
    |
    +--> TXT
    +--> DOCX
    +--> PDF
```

## Project structure

```text
LegalEase/
├── ai_core/
│   ├── __init__.py
│   └── gemini_generator.py
├── api/
│   ├── __init__.py
│   ├── main.py
│   └── routes.py
├── services/
│   ├── __init__.py
│   └── document_service.py
├── utils/
│   ├── __init__.py
│   ├── config.py
│   └── text_utils.py
├── tests/
│   ├── __init__.py
│   ├── test_api.py
│   └── test_documents.py
├── assets/
│   └── .gitkeep
├── .streamlit/
│   └── config.toml
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── Dockerfile
├── Procfile
└── README.md
```

## VS Code setup

### 1. Open the project

Open the `LegalEase` folder in VS Code.

### 2. Create a virtual environment

Windows PowerShell:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

Windows CMD:

```cmd
py -3 -m venv .venv
.venv\Scripts\activate.bat
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install packages

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and put your Gemini API key in `GEMINI_API_KEY`.

The code uses Google's current `google-genai` Python SDK. The model is configurable through `GEMINI_MODEL`.

### 5. Start FastAPI

From the project root:

```bash
uvicorn api.main:app --reload --host 127.0.0.1 --port 8000
```

Test in a browser:

```text
http://127.0.0.1:8000/
http://127.0.0.1:8000/health
http://127.0.0.1:8000/docs
```

### 6. Start Streamlit

Open a second VS Code terminal, activate the same virtual environment, then:

```bash
streamlit run app.py
```

Open the local URL Streamlit prints, normally `http://localhost:8501`.

## Testing without an API call

For local UI/API testing without spending Gemini quota, temporarily set:

```env
MOCK_LLM=true
```

Then restart FastAPI and Streamlit. The mock generator exercises the complete request → response → editing → export flow without contacting Gemini.

Set `MOCK_LLM=false` again for real AI generation.

## API example

```bash
curl -X POST "http://127.0.0.1:8000/generate" \
  -H "Content-Type: application/json" \
  -d '{
    "document_type": "Freelance Work Contract",
    "parties": "Jane Doe (Service Provider), TechNova Inc. (Client)",
    "terms": "Payment within 30 days; Deliverables due by the agreed deadline; Confidentiality must be maintained; Either party may terminate with 15 days notice",
    "effective_date": "April 10, 2026"
  }'
```

## Exports

The frontend can download:

- `.txt` — plain text
- `.docx` — editable Word document with title, sections, terms table, header branding, and footer
- `.pdf` — formatted PDF with title, sections, terms table, header/footer branding

## Tests

```bash
pytest -q
```

The tests do not call Gemini. They use the deterministic mock generator and test API validation plus DOCX/PDF/TXT generation.

## Docker

```bash
docker build -t legalease .
docker run --rm -p 8000:8000 --env-file .env legalease
```

For Streamlit in Docker, run a separate container/process using the same image and command:

```bash
docker run --rm -p 8501:8501 --env-file .env legalease streamlit run app.py --server.address=0.0.0.0
```
