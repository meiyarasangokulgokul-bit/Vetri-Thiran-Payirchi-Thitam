from __future__ import annotations

from dataclasses import dataclass

from utils.config import Settings
from utils.text_utils import clamp_text, sanitize_text


@dataclass
class GenerationInput:
    document_type: str
    parties: str
    terms: str
    effective_date: str


class GeminiDocumentGenerator:
    """Gemini-backed legal document draft generator."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._client = None

    @property
    def client(self):
        if self._client is None:
            if not self.settings.gemini_api_key:
                raise RuntimeError("GEMINI_API_KEY is not configured.")
            try:
                from google import genai
            except ImportError as exc:
                raise RuntimeError("The google-genai package is not installed. Run: pip install -r requirements.txt") from exc
            self._client = genai.Client(api_key=self.settings.gemini_api_key)
        return self._client

    def _build_prompt(self, data: GenerationInput) -> str:
        return f"""You are a careful legal-document drafting assistant.

Create a professional DRAFT of the requested legal document using only the supplied facts. Do not invent names, dates, money amounts, addresses, governing law, statutory citations, or obligations that the user did not provide. Where a legally important fact is missing, insert a clear bracketed placeholder such as [GOVERNING LAW NOT PROVIDED] rather than guessing.

The output must be plain text, not Markdown, JSON, HTML, or code fences.

Required structure:
1. Document title
2. Introductory paragraph identifying the parties and effective date
3. Clearly numbered substantive sections appropriate to the requested document type
4. Terms/obligations based on the supplied terms
5. Termination, confidentiality, dispute/governing-law language only when appropriate; if facts are missing, use bracketed placeholders
6. Signature blocks for the parties
7. A final short note: "DRAFT FOR REVIEW - NOT LEGAL ADVICE"

Do not claim that the document is legally valid, enforceable, or jurisdiction-specific unless that fact is supplied.

Document type: {data.document_type}
Parties: {data.parties}
Effective date: {data.effective_date}
Terms and conditions: {data.terms}
"""

    def generate_document(self, data: GenerationInput) -> str:
        if self.settings.mock_llm:
            return self._mock_document(data)

        prompt = self._build_prompt(data)
        from google.genai import types

        response = self.client.models.generate_content(
            model=self.settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                temperature=0.2,
                max_output_tokens=8192,
                candidate_count=1,
            ),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return clamp_text(sanitize_text(text), self.settings.max_document_chars)

    @staticmethod
    def _mock_document(data: GenerationInput) -> str:
        terms = [t.strip() for t in data.terms.replace(";", "\n").splitlines() if t.strip()]
        term_lines = "\n".join(f"{i}. {term}" for i, term in enumerate(terms, 1)) or "[TERMS NOT PROVIDED]"
        return f"""{data.document_type.upper()}

This draft is made effective as of {data.effective_date} between {data.parties}.

1. PURPOSE
The parties intend to establish the rights and obligations described in this draft for the document type identified above.

2. PARTIES
{data.parties}

3. TERMS AND CONDITIONS
{term_lines}

4. ADDITIONAL PROVISIONS
[Additional jurisdiction-specific provisions should be reviewed and completed by a qualified legal professional.]

5. SIGNATURES

Party 1: ______________________________    Date: ______________
Party 2: ______________________________    Date: ______________

DRAFT FOR REVIEW - NOT LEGAL ADVICE
"""
