from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from api.routes import router
from utils.config import get_settings

settings = get_settings()
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="AI-powered legal document draft generator.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def root():
    return {"name": settings.app_name, "version": settings.app_version, "status": "running"}


@app.get("/health")
def health():
    return {"status": "ok", "ai_configured": bool(settings.gemini_api_key or settings.mock_llm), "mock_llm": settings.mock_llm}
