from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator

from ai_core.gemini_generator import GenerationInput, GeminiDocumentGenerator
from utils.config import get_settings
from utils.text_utils import sanitize_text

router = APIRouter()
settings = get_settings()
generator = GeminiDocumentGenerator(settings)


class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=3, max_length=200)
    parties: str = Field(..., min_length=3, max_length=5000)
    terms: str = Field(..., min_length=3, max_length=15000)
    effective_date: str = Field(..., min_length=3, max_length=100)

    @field_validator("document_type", "parties", "terms", "effective_date")
    @classmethod
    def clean_fields(cls, value: str) -> str:
        value = sanitize_text(value)
        if not value:
            raise ValueError("Field cannot be empty.")
        return value


class DocumentResponse(BaseModel):
    document_type: str
    content: str


@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest) -> DocumentResponse:
    try:
        content = generator.generate_document(
            GenerationInput(
                document_type=request.document_type,
                parties=request.parties,
                terms=request.terms,
                effective_date=request.effective_date,
            )
        )
        return DocumentResponse(document_type=request.document_type, content=content)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Document generation failed: {exc}") from exc
