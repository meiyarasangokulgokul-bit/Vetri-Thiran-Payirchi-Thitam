from __future__ import annotations

import html
import os
from datetime import date

import requests
import streamlit as st

from services.document_service import format_docx, format_pdf, format_txt
from utils.config import get_settings
from utils.text_utils import sanitize_text, split_terms, text_to_html

settings = get_settings()

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .hero { padding: 1.4rem 1.6rem; border: 1px solid rgba(124,58,237,.35); border-radius: 18px; background: linear-gradient(135deg, rgba(124,58,237,.15), rgba(30,41,59,.25)); }
    .hero h1 { margin: 0; }
    .muted { color: #a7b0c2; }
    .preview { max-height: 620px; overflow-y: auto; padding: 28px; border-radius: 16px; background: #111827; border: 1px solid #273449; line-height: 1.65; }
    .preview h3 { color: #c4b5fd; margin-top: 1.2rem; }
    .preview p { color: #e5e7eb; }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="hero"><h1>⚖️ LegalEase</h1><p class="muted">AI-powered legal document drafting, editing and export.</p></div>',
    unsafe_allow_html=True,
)
st.caption("Drafting assistant only — review important documents with a qualified legal professional.")

if "document" not in st.session_state:
    st.session_state.document = ""
if "generated_type" not in st.session_state:
    st.session_state.generated_type = ""

with st.sidebar:
    st.header("Document setup")
    document_type = st.selectbox(
        "Document type",
        [
            "Employment Contract",
            "Lease Agreement",
            "Non-Disclosure Agreement (NDA)",
            "Employment Offer Letter",
            "Freelance Work Contract",
            "Service Agreement",
            "General Agreement",
            "Custom",
        ],
    )
    if document_type == "Custom":
        document_type = st.text_input("Custom document type", placeholder="e.g. Consulting Agreement")

    parties = st.text_area(
        "Parties involved",
        placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=100,
    )
    terms = st.text_area(
        "Terms & conditions",
        placeholder="Payment within 30 days; Deliverables due by the agreed deadline; Confidentiality must be maintained; Either party may terminate with 15 days notice",
        height=170,
        help="Separate individual terms with semicolons or new lines.",
    )
    effective_date = st.date_input("Effective date", value=date.today())
    logo = st.file_uploader("Optional logo", type=["png", "jpg", "jpeg"])

    generate = st.button("Generate Document", type="primary", use_container_width=True)

if generate:
    if not all([document_type.strip(), parties.strip(), terms.strip()]):
        st.error("Please complete document type, parties, and terms before generating.")
    else:
        payload = {
            "document_type": document_type.strip(),
            "parties": parties.strip(),
            "terms": terms.strip(),
            "effective_date": effective_date.isoformat(),
        }
        try:
            with st.spinner("Generating your draft..."):
                response = requests.post(
                    f"{settings.backend_url.rstrip('/')}/generate",
                    json=payload,
                    timeout=settings.request_timeout_seconds,
                )
            if response.ok:
                body = response.json()
                st.session_state.document = body["content"]
                st.session_state.generated_type = body["document_type"]
                st.success("Document generated successfully.")
            else:
                try:
                    detail = response.json().get("detail", response.text)
                except Exception:
                    detail = response.text
                st.error(f"Backend error ({response.status_code}): {detail}")
        except requests.RequestException as exc:
            st.error(f"Could not connect to FastAPI at {settings.backend_url}: {exc}")

if st.session_state.document:
    st.divider()
    left, right = st.columns([1.15, 0.85], gap="large")

    with left:
        st.subheader("Preview")
        preview = text_to_html(st.session_state.document)
        st.markdown(f'<div class="preview">{preview}</div>', unsafe_allow_html=True)

    with right:
        st.subheader("Edit Document")
        edited = st.text_area(
            "Edit the generated text",
            value=st.session_state.document,
            height=560,
            label_visibility="collapsed",
        )
        if edited != st.session_state.document:
            st.session_state.document = edited
            st.info("Your edits are stored in this session and will be used for downloads.")

    st.divider()
    st.subheader("Download")
    content = sanitize_text(st.session_state.document)
    doc_type = st.session_state.generated_type or document_type
    col1, col2, col3 = st.columns(3)

    with col1:
        st.download_button(
            "Download TXT",
            data=format_txt(content),
            file_name="legalease_document.txt",
            mime="text/plain",
            use_container_width=True,
        )
    with col2:
        st.download_button(
            "Download DOCX",
            data=format_docx(content, doc_type, logo_bytes=logo.getvalue() if logo else None),
            file_name="legalease_document.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            use_container_width=True,
        )
    with col3:
        st.download_button(
            "Download PDF",
            data=format_pdf(content, doc_type, logo_bytes=logo.getvalue() if logo else None),
            file_name="legalease_document.pdf",
            mime="application/pdf",
            use_container_width=True,
        )

    with st.expander("Input summary"):
        st.write(f"**Document:** {html.escape(doc_type)}")
        st.write(f"**Parties:** {html.escape(parties)}")
        st.write(f"**Effective date:** {effective_date.isoformat()}")
        st.write("**Terms:**")
        for term in split_terms(terms):
            st.write(f"- {term}")
else:
    st.info("Enter the document details in the sidebar and click Generate Document.")
