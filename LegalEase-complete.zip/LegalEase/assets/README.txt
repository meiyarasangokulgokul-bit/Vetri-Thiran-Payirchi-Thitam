Place an optional application logo here if you want to extend the UI branding. The current Streamlit UI also supports uploading a logo directly in the sidebar.
