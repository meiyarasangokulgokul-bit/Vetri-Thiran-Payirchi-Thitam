from __future__ import annotations

from io import BytesIO
import os
import re
import tempfile

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt
from fpdf import FPDF

from utils.text_utils import sanitize_text, split_terms


def _sections(text: str) -> list[tuple[str, list[str]]]:
    clean = sanitize_text(text)
    chunks = re.split(r"\n\s*\n", clean)
    sections: list[tuple[str, list[str]]] = []
    current_title = ""
    current_body: list[str] = []
    for chunk in chunks:
        lines = [line.strip() for line in chunk.splitlines() if line.strip()]
        if not lines:
            continue
        first = lines[0]
        is_heading = bool(re.match(r"^(\d+\.?\s+|[A-Z][A-Z0-9 &/'-]{4,}$)", first)) and len(first) < 120
        if is_heading:
            if current_title or current_body:
                sections.append((current_title, current_body))
            current_title = first
            current_body = lines[1:]
        else:
            current_body.extend(lines)
    if current_title or current_body:
        sections.append((current_title, current_body))
    return sections


def format_txt(text: str) -> bytes:
    return sanitize_text(text).encode("utf-8")


def format_docx(text: str, doc_type: str, logo_bytes: bytes | None = None) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)
    styles["Title"].font.name = "Times New Roman"
    styles["Title"].font.size = Pt(18)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(18)

    if logo_bytes:
        try:
            logo_stream = BytesIO(logo_bytes)
            p_logo = doc.add_paragraph()
            p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_logo.add_run().add_picture(logo_stream, width=Inches(1.2))
        except Exception:
            pass

    subtitle = doc.add_paragraph("LegalEase - AI-generated draft")
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.runs[0].italic = True
    subtitle.runs[0].font.size = Pt(9)

    for heading, body in _sections(text):
        if heading:
            p = doc.add_paragraph()
            r = p.add_run(heading)
            r.bold = True
            r.font.name = "Times New Roman"
            r.font.size = Pt(12)
        for line in body:
            p = doc.add_paragraph(line)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing = 1.15

    terms = _extract_terms(text)
    if terms:
        doc.add_paragraph()
        p = doc.add_paragraph()
        r = p.add_run("KEY TERMS")
        r.bold = True
        table = doc.add_table(rows=1, cols=2)
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.style = "Table Grid"
        table.rows[0].cells[0].text = "#"
        table.rows[0].cells[1].text = "Term"
        for idx, term in enumerate(terms, 1):
            cells = table.add_row().cells
            cells[0].text = str(idx)
            cells[1].text = term
            for cell in cells:
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("LegalEase - Draft for review - Not legal advice").font.size = Pt(8)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()


def _extract_terms(text: str) -> list[str]:
    lines = []
    in_terms = False
    for raw in sanitize_text(text).splitlines():
        line = raw.strip()
        if re.match(r"^(3\.?\s*)?TERMS( AND CONDITIONS)?$", line, re.I):
            in_terms = True
            continue
        if in_terms and re.match(r"^\d+\.\s+", line):
            lines.append(re.sub(r"^\d+\.\s+", "", line))
        elif in_terms and re.match(r"^[A-Z][A-Z &'-]{5,}$", line):
            break
    return lines[:25]


class _LegalEasePDF(FPDF):
    def __init__(self, doc_type: str):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.doc_type = doc_type
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        self.set_font("Helvetica", "B", 9)
        self.cell(0, 6, "LegalEase", align="C", new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(160, 160, 160)
        self.line(15, 14, 195, 14)
        self.ln(5)

    def footer(self):
        self.set_y(-13)
        self.set_font("Helvetica", "I", 7)
        self.cell(0, 5, "LegalEase - Draft for review - Not legal advice", align="C")


def format_pdf(text: str, doc_type: str, logo_bytes: bytes | None = None) -> bytes:
    pdf = _LegalEasePDF(doc_type)
    pdf.set_margins(15, 18, 15)
    pdf.add_page()

    if logo_bytes:
        temp_path = None
        try:
            suffix = ".png"
            with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
                tmp.write(logo_bytes)
                temp_path = tmp.name
            pdf.image(temp_path, x=88, y=18, w=34)
            pdf.ln(28)
        except Exception:
            pass
        finally:
            if temp_path:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass

    pdf.set_x(pdf.l_margin)
    pdf.set_font("Helvetica", "B", 16)
    pdf.multi_cell(pdf.epw, 8, sanitize_text(doc_type).upper(), align="C")
    pdf.set_font("Helvetica", "I", 8)
    pdf.multi_cell(pdf.epw, 5, "LegalEase - AI-generated draft", align="C")
    pdf.ln(5)

    for heading, body in _sections(text):
        if heading:
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(pdf.epw, 6, heading)
            pdf.ln(1)
        pdf.set_font("Helvetica", "", 10)
        for line in body:
            if re.match(r"^\d+\.\s+", line):
                pdf.multi_cell(pdf.epw, 5.5, line)
            else:
                pdf.multi_cell(pdf.epw, 5.5, line)
            pdf.ln(1)
        pdf.ln(2)

    raw = pdf.output()
    return bytes(raw)
