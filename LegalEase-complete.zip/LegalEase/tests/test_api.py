import os

os.environ["MOCK_LLM"] = "true"

from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_generate():
    response = client.post(
        "/generate",
        json={
            "document_type": "Freelance Work Contract",
            "parties": "Jane Doe (Provider), TechNova Inc. (Client)",
            "terms": "Payment within 30 days; Confidentiality must be maintained",
            "effective_date": "2026-04-10",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["document_type"] == "Freelance Work Contract"
    assert "DRAFT FOR REVIEW" in data["content"]


def test_generate_rejects_missing_field():
    response = client.post(
        "/generate",
        json={"document_type": "NDA", "parties": "A and B", "terms": "Confidentiality"},
    )
    assert response.status_code == 422
