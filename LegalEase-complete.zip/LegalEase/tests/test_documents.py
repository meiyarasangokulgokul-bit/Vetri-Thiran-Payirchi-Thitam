from docx import Document

from services.document_service import format_docx, format_pdf, format_txt


def sample():
    return """FREELANCE WORK CONTRACT

This agreement is effective as of April 10, 2026 between Jane Doe (Service Provider) and TechNova Inc. (Client).

1. PURPOSE
The parties agree to the freelance services described in this draft.

2. TERMS AND CONDITIONS
1. Payment within 30 days
2. Deliverables due by the agreed deadline
3. Confidentiality must be maintained

3. SIGNATURES
Party 1: ____________________ Date: __________
Party 2: ____________________ Date: __________

DRAFT FOR REVIEW - NOT LEGAL ADVICE"""


def test_txt_export():
    data = format_txt(sample())
    assert b"FREELANCE WORK CONTRACT" in data


def test_docx_export_is_readable():
    data = format_docx(sample(), "Freelance Work Contract")
    doc = Document(__import__("io").BytesIO(data))
    assert any("FREELANCE WORK CONTRACT" in p.text for p in doc.paragraphs)


def test_pdf_export_has_bytes():
    data = format_pdf(sample(), "Freelance Work Contract")
    assert data.startswith(b"%PDF")
    assert len(data) > 500
