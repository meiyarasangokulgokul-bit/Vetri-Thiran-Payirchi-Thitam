import html
import re
from typing import Iterable


def sanitize_text(text: str) -> str:
    """Normalize AI text for document exports while preserving useful punctuation."""
    if not text:
        return ""
    replacements = {
        "“": '"', "”": '"', "‘": "'", "’": "'",
        "–": "-", "—": "-", "…": "...", "\u00a0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n{4,}", "\n\n\n", text)
    return text.strip()


def split_terms(terms: str) -> list[str]:
    return [part.strip(" -\t") for part in re.split(r";|\n", terms or "") if part.strip()]


def text_to_html(text: str) -> str:
    """Convert plain generated text to safe preview HTML."""
    safe = html.escape(sanitize_text(text))
    blocks = re.split(r"\n\s*\n", safe)
    rendered: list[str] = []
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue
        if len(lines) == 1 and (lines[0].isupper() or re.match(r"^(\d+\.|[A-Z][A-Z\s-]{4,})$", lines[0])):
            rendered.append(f"<h3>{lines[0]}</h3>")
        else:
            rendered.append(f"<p>{'<br>'.join(lines)}</p>")
    return "".join(rendered)


def clamp_text(text: str, max_chars: int) -> str:
    text = sanitize_text(text)
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "\n\n[Document truncated by application limit.]"
